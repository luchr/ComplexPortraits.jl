Contents of directory Examples:

Example0:  phase plot of the function f(z)=(z^5-1)/(z^10+.1) with contour lines
Example1:  analytic landscape of the same function
Example2:  logarithmic analytic landscape of the same function
Example3:  compressed analytic landscape of the same function
Example4:  compressed analytic landscape on Riemann sphere of the same function
Example5:  the same for a rational function with many poles and zeros
Example6:  phase plot of f(z)=exp(z) on the sphere (essential singularity at infinity)
Example7:  the function 3*log(z)-log(z^3) (zero on one third of the Riemann sphere) 
Example8:  the function sqrt(1-cos(4*z)^2)-sin(4*z) on the Riemann sphere 
Example9:  the function sin(2*x)*sin(y)^(5/2)+1i*cos(2*x)*cos(y)^3, where z=x+i*y
Example10: an object to hang on your Christmas tree (the same function as Example 5)
